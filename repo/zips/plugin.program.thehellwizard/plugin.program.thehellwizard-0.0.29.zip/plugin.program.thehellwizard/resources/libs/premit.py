################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib2,urllib
import re
import uservar
import time
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from datetime import date, datetime, timedelta
from resources.libs import wizard as wiz

ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
ADDON          = wiz.addonId(ADDON_ID)
DIALOG         = xbmcgui.Dialog()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,      'addons')
USERDATA       = os.path.join(HOME,      'userdata')
PLUGIN         = os.path.join(ADDONS,    ADDON_ID)
PACKAGES       = os.path.join(ADDONS,    'packages')
ADDONDATA      = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADDOND         = os.path.join(USERDATA,  'addon_data')
PREMFOLD       = os.path.join(ADDONDATA, 'prem')
ICON           = os.path.join(PLUGIN,    'icon.png')
TODAY          = date.today()
TOMORROW       = TODAY + timedelta(days=1)
THREEDAYS      = TODAY + timedelta(days=3)
KEEPPREM       = wiz.getS('keepprem')
PREMSAVE       = wiz.getS('premlastsave')
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
ORDER          = ['seren', 'gaia']

PREMID = { 
	'seren': {
		'name'     : 'Premiumize Seren',
		'plugin'   : 'plugin.video.seren',
		'saved'    : 'premiumizeseren',
		'path'     : os.path.join(ADDONS, 'plugin.video.seren'),
		'icon'     : os.path.join(ADDONS, 'plugin.video.seren', 'icon.png'),
		'fanart'   : os.path.join(ADDONS, 'plugin.video.seren', 'fanart.jpg'),
		'file'     : os.path.join(PREMFOLD, 'seren_premiumize'),
		'settings' : os.path.join(ADDOND, 'plugin.video.seren', 'settings.xml'),
		'default'  : 'premiumize.pin',
		'data'     : ['premiumize.autodelete', 'premiumize.enabled', 'premiumize.hosters', 'premiumize.pin', 'premiumize.threshold', 'premiumize.torrents', 'general.cachelocation'],
		'activate' : ''},
	'gaia': {
		'name'     : 'Premiumize Gaia',
		'plugin'   : 'plugin.video.gaia',
		'saved'    : 'premiumizegaia',
		'path'     : os.path.join(ADDONS, 'plugin.video.gaia'),
		'icon'     : os.path.join(ADDONS, 'plugin.video.gaia', 'icon.png'),
		'fanart'   : os.path.join(ADDONS, 'plugin.video.gaia', 'fanart.jpg'),
		'file'     : os.path.join(PREMFOLD, 'gaia_premiumize'),
		'settings' : os.path.join(ADDOND, 'plugin.video.gaia', 'settings.xml'),
		'default'  : 'accounts.debrid.premiumize.pin',
		'data'     : ['accounts.debrid.premiumize.enabled', 'accounts.debrid.premiumize.encryption', 'accounts.debrid.premiumize.method', 'accounts.debrid.premiumize.pin', 'accounts.debrid.premiumize.removal', 'accounts.debrid.premiumize.removal.failure', 'accounts.debrid.premiumize.removal.launch', 'accounts.debrid.premiumize.removal.playback', 'accounts.debrid.premiumize.user'],
		'activate' : ''}
}

def premUser(who):
	user=None
	if PREMID[who]:
		if os.path.exists(PREMID[who]['path']):
			try:
				add = wiz.addonId(PREMID[who]['plugin'])
				user = add.getSetting(PREMID[who]['default'])
			except:
				pass
	return user

def premIt(do, who):
	if not os.path.exists(ADDONDATA): os.makedirs(ADDONDATA)
	if not os.path.exists(PREMFOLD):  os.makedirs(PREMFOLD)
	if who == 'all':
		for log in ORDER:
			if os.path.exists(PREMID[log]['path']):
				try:
					addonid   = wiz.addonId(PREMID[log]['plugin'])
					default   = PREMID[log]['default']
					user      = addonid.getSetting(default)
					if user == '' and do == 'update': continue
					updatePrem(do, log)
				except: pass
			else: wiz.log('[Premiumize Data] %s(%s) is not installed' % (PREMID[log]['name'],PREMID[log]['plugin']), xbmc.LOGERROR)
		wiz.setS('premlastsave', str(THREEDAYS))
	else:
		if PREMID[who]:
			if os.path.exists(PREMID[who]['path']):
				updatePrem(do, who)
		else: wiz.log('[Premiumize Data] Invalid Entry: %s' % who, xbmc.LOGERROR)

def premSaved(who, over=False):
	if who == 'all':
		for prem in PREMID:
			clearSaved(prem,  True)
	elif PREMID[who]:
		file = PREMID[who]['file']
		if os.path.exists(file): 
			os.remove(file)
			wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, PREMID[who]['name']), '[COLOR %s]Premiumize Data: Removed![/COLOR]' % COLOR2, 2000, PREMID[who]['icon'])
		wiz.setS(PREMID[who]['saved'], '')
	if over == False: wiz.refresh()

def updatePrem(do, who):
	file      = PREMID[who]['file']
	settings  = PREMID[who]['settings']
	data      = PREMID[who]['data']
	addonid   = wiz.addonId(PREMID[who]['plugin'])
	saved     = PREMID[who]['saved']
	default   = PREMID[who]['default']
	user      = addonid.getSetting(default)
	suser     = wiz.getS(saved)
	name      = PREMID[who]['name']
	icon      = PREMID[who]['icon']

	if do == 'update':
		if not user == '':
			try:
				with open(file, 'w') as f:
					for prem in data:
						f.write('<prem>\n\t<id>%s</id>\n\t<value>%s</value>\n</prem>\n' % (prem, addonid.getSetting(prem)))
					f.close()
				user = addonid.getSetting(default)
				wiz.setS(saved, user)
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name),'[COLOR %s]Premiumize Data: Saved![/COLOR]' % COLOR2, 2000, icon)
			except Exception, e:
				wiz.log("[Premiumize Data] Unable to Update %s (%s)" % (who, str(e)), xbmc.LOGERROR)
		else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name),'[COLOR %s]Premiumize Data: Not Registered![/COLOR]' % COLOR2, 2000, icon)
	elif do == 'restore':
		if os.path.exists(file):
			f = open(file,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			match = re.compile('<prem><id>(.+?)</id><value>(.+?)</value></prem>').findall(g)
			try:
				if len(match) > 0:
					for prem, value in match:
						addonid.setSetting(prem, value)
				user = addonid.getSetting(default)
				wiz.setS(saved, user)
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name), '[COLOR %s]Premiumize: Restored![/COLOR]' % COLOR2, 2000, icon)
			except Exception, e:
				wiz.log("[Premiumize Data] Unable to Restore %s (%s)" % (who, str(e)), xbmc.LOGERROR)
		#else: wiz.LogNotify(name,'prem Data: [COLOR red]Not Found![/COLOR]', 2000, icon)
	elif do == 'clearaddon':
		wiz.log('%s SETTINGS: %s' % (name, settings), xbmc.LOGDEBUG)
		if os.path.exists(settings):
			try:
				f = open(settings, "r"); lines = f.readlines(); f.close()
				f = open(settings, "w")
				for line in lines:
					match = wiz.parseDOM(line, 'setting', ret='id')
					if len(match) == 0: f.write(line)
					else:
						if match[0] not in data: f.write(line)
						else: wiz.log('Removing Line: %s' % line, xbmc.LOGNOTICE)
				f.close()
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, name),'[COLOR %s]Addon Data: Cleared![/COLOR]' % COLOR2, 2000, icon)
			except Exception, e:
				wiz.log("[Premiumize Data] Unable to Clear Addon %s (%s)" % (who, str(e)), xbmc.LOGERROR)
	wiz.refresh()

def autoUpdate(who):
	if who == 'all':
		for log in PREMID:
			if os.path.exists(PREMID[log]['path']):
				autoUpdate(log)
	elif PREMID[who]:
		if os.path.exists(PREMID[who]['path']):
			u  = premUser(who)
			su = wiz.getS(PREMID[who]['saved'])
			n = PREMID[who]['name']
			if u == None or u == '': return
			elif su == '': premIt('update', who)
			elif not u == su:
				if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to save the [COLOR %s]Premiumize[/COLOR] data for [COLOR %s]%s[/COLOR]?" % (COLOR2, COLOR1, COLOR1, n), "Addon: [COLOR green][B]%s[/B][/COLOR]" % u, "Saved:[/COLOR] [COLOR red][B]%s[/B][/COLOR]" % su if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]', yeslabel="[B][COLOR green]Save Data[/COLOR][/B]", nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
					premIt('update', who)
			else: premIt('update', who)

def importlist(who):
	if who == 'all':
		for log in PREMID:
			if os.path.exists(PREMID[log]['file']):
				importlist(log)
	elif PREMID[who]:
		if os.path.exists(PREMID[who]['file']):
			d  = PREMID[who]['default']
			sa = PREMID[who]['saved']
			su = wiz.getS(sa)
			n  = PREMID[who]['name']
			f  = open(PREMID[who]['file'],mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			m  = re.compile('<prem><id>%s</id><value>(.+?)</value></prem>' % d).findall(g)
			if len(m) > 0:
				if not m[0] == su:
					if DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to import the [COLOR %s]Premiumize[/COLOR] data for [COLOR %s]%s[/COLOR]?" % (COLOR2, COLOR1, COLOR1, n), "File: [COLOR green][B]%s[/B][/COLOR]" % m[0], "Saved:[/COLOR] [COLOR red][B]%s[/B][/COLOR]" % su if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]', yeslabel="[B][COLOR green]Save Data[/COLOR][/B]", nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
						wiz.setS(sa, m[0])
						wiz.log('[Import Data] %s: %s' % (who, str(m)), xbmc.LOGNOTICE)
					else: wiz.log('[Import Data] Declined Import(%s): %s' % (who, str(m)), xbmc.LOGNOTICE)
				else: wiz.log('[Import Data] Duplicate Entry(%s): %s' % (who, str(m)), xbmc.LOGNOTICE)
			else: wiz.log('[Import Data] No Match(%s): %s' % (who, str(m)), xbmc.LOGNOTICE)

def activatePrem(who):
	if PREMID[who]:
		if os.path.exists(PREMID[who]['path']): 
			act     = PREMID[who]['activate']
			addonid = wiz.addonId(PREMID[who]['plugin'])
			if act == '': addonid.openSettings()
			else: url = xbmc.executebuiltin(PREMID[who]['activate'])
		else: DIALOG.ok(ADDONTITLE, '%s is not currently installed.' % PREMID[who]['name'])
	else: 
		wiz.refresh()
		return
	check = 0
	while premUser(who) == None or premUser(who) == "":
		if check == 30: break
		check += 1
		time.sleep(10)
	wiz.refresh()