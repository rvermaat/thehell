import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmlwdHY=')

name = b.b64decode('aXB0dg==')

host = b.b64decode('aHR0cDovL2NocmlzcHR2Lm5ldA==')

port = b.b64decode('ODM=')