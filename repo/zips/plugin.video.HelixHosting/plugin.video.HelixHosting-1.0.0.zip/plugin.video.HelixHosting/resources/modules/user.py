import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLkhlbGl4SG9zdGluZw==')

name = b.b64decode('W0NPTE9SbGltZV1IZWxpeFsvQ09MT1JdIFtDT0xPUndoaXRlXUhvc3RpbmdbL0NPTE9SXQ==')

host = b.b64decode('aHR0cDovL2ZmZmZmLnNwYWNl')

port = b.b64decode('ODM=')